%% 6D data structure of mag and phase (if under noise, value is set to NA) 
% (freq, int, dataset, structure, dir, mousetype)=(23, 8, 6, 3, 2, 6)

mag=load('magDataAll_ortho7'); mag=mag.mag;
phase=load('phDataAll_ortho7'); phase=phase.phase;
magME=[0.76	1.082666667	0.911333333	0.855333333	0.905333333	0.881666667	0.92 ...
    0.821666667	0.777666667	0.816333333	0.828333333	0.600666667	0.570666667 ...
    0.456333333	0.358333333	0.303666667	0.234666667	0.224666667	0.351666667 ...
    0.382666667	0.584666667	0.819333333	0.921333333];
magME=magME*10;

magME=repmat(magME',[1,8]);
magME=magME.*repmat(10.^((-7:1:0)/2),[size(magME,1),1]);
mag_raw=mag; phase_raw=phase;
[numF, numA, numData, numStructs, numDir, numMtype]=size(mag);
freq=(2:0.5:13)*1e3; 
dataset=1:1:numData;
structure={'BM','TM','RL'};
dirName={'transverse','radial'};
mousetype={'CBA live','CBA dead','P499 live','P499 dead','Tecta live','Tecta dead'};


%% plotting the tuning curve of all the dataset
dispIdx=[1,2,1]; % indexes for the [structure, dir, mousetype]
for j=6
    figure(1); set(gcf,'Position', [50 400 350 250]); clf;
    magPlot(freq, squeeze(mag(:,:,j,dispIdx(1),dispIdx(2),dispIdx(3))), ...
        '','','',[]); set(gca,'ytick',10.^(-1:2)); grid on; grid minor;
    figure(2); set(gcf,'Position', [50 100 350 150]); clf;
    phasePlot(freq, squeeze(phase(:,:,j,dispIdx(1),dispIdx(2),dispIdx(3)))/2/pi, ...
        '', '', '',[-5 0.5]); grid on; set(gca,'Xtick',2:2:12,'Ytick',-4:1:2);
     pause(0.2);
end

%% taking averages over dataset
structureToTest=2;
dirToTest=2;
mousetypeToTest=1;
effNum=[4,3,3,3,4,4]; nPolMag=[5,4,5,5,6,6]; nPolPhase=[3,3,3,3,3,3];
effFlag=repmat(sum(isfinite(mag),3),[1,1,numData,1,1,1]);
magTemp=mag; magTemp(effFlag<effNum(mousetypeToTest))=nan; 
magAve=squeeze(exp(nanmean(log(magTemp(:,:,:,:,:,:)),3))); 
magSE=squeeze(nanstd(squeeze(magTemp(:,:,:,structureToTest,dirToTest, ...
    mousetypeToTest)),[],3))./sqrt(sum(isfinite(magTemp(:,:,:,structureToTest, ...
    dirToTest,mousetypeToTest)),3)); 
phaseTemp=phase; phaseTemp(effFlag<effNum(mousetypeToTest))=nan;
phaseAve=squeeze(nanmedian(phaseTemp,3));
phaseSE=squeeze(nanstd(squeeze(phaseTemp(:,:,:,structureToTest,dirToTest, ...
    mousetypeToTest)),[],3))./sqrt(sum(isfinite(phaseTemp(:,:,:,structureToTest, ...
    dirToTest,mousetypeToTest)),3)); 

flagTemp=(squeeze(magAve(:,:,structureToTest,dirToTest,mousetypeToTest))-magSE<=0);
magSE(flagTemp)=0;

% figure(3); set(gcf,'Position', [250 400 350 250]); 
% magPlot_3(freq, squeeze(magAve(:,:,structureToTest,dirToTest,mousetypeToTest)), ...
%     0,'','','',[],magSE); grid on;set(gca,'ytick',10.^(-1:2)); grid minor;
% figure(4); set(gcf,'Position', [250 100 350 250]); 
% phasePlot_3(freq, squeeze(phaseAve(:,:,structureToTest,dirToTest,mousetypeToTest)) ...
%     /2/pi, 0, '','', '',[-5 1], phaseSE/2/pi); grid on; set(gca,'Xtick',2:2:12,'Ytick',-10:1:2);
figure(5); set(gcf,'Position', [250 500 350 250]); 
magPlot_3(freq, squeeze(magAve(:,:,structureToTest,dirToTest,mousetypeToTest))./magME, ...
    0,'','','',[1.1e-1 2e4],magSE./magME); grid on; set(gca,'ytick',10.^(0:5)); grid minor; 
clear effFlag magTemp phaseTemp

% print mean,std of gain between 10 and 80 db peaks in BM,RL,TM
gain=squeeze(nanmax(mag(:,1,:,structureToTest,dirToTest,mousetypeToTest),[],1)*10^(7/2)./ ...
    nanmax(mag(:,8,:,structureToTest,dirToTest,mousetypeToTest),[],1)); 
gain=20*log10(gain);
% fprintf('Gain: Mean = %0.1f dB, SE = %0.1f dB\n',nanmean(gain), ...
%     nanstd(gain)/sqrt(sum(isfinite(gain))));

% print phase velocity at RF and CF
RFidx=6; CFidx=17; 
dist=3.79e-3; % distance of measurement spot from the stapes (m)
phaseTemp=squeeze(nanmean(phase(:,:,:,structureToTest,dirToTest,mousetypeToTest),2));
phaseVelocityRF=freq(RFidx)*dist./abs(phaseTemp(RFidx,:));
phaseVelocityCF=freq(CFidx)*dist./abs(phaseTemp(CFidx,:));
% fprintf('Phase Velocity at RF = %0.1f +- %0.1f m/s\n',...
%     nanmean(phaseVelocityRF),nanstd(phaseVelocityRF)/sqrt(sum(isfinite(phaseVelocityRF))));
% fprintf('Phase Velocity at CF = %0.1f +- %0.1f m/s\n',...
%     nanmean(phaseVelocityCF),nanstd(phaseVelocityCF)/sqrt(sum(isfinite(phaseVelocityCF))));

% t-test on phase velocities between locations
% [h,p]=ttest(phaseVelocityRF(isfinite(phaseVelocityRF)), ...
%     phaseVelocityRFBM(isfinite(phaseVelocityRFBM)))
% [h,p]=ttest(phaseVelocityCF(isfinite(phaseVelocityCF)), ...
%     phaseVelocityCFBM(isfinite(phaseVelocityCFBM)))

%% magnitude ratio, phase difference plots (ratio and subtract first and then average)
numerTest=[2,2]; % indices for [structure,direction] in the numerator
denomTest=[1,1]; % indices for [structure,direction] in the denominator
mousetypeToTest=2; datasetToTest=[1:6];
effNum=[4,3,3,3,3,4]; nPolMag=[5,4,5,5,6,6]; nPolPhase=[4,3,3,3,3,3];
magRatio=squeeze(mag(:,:,datasetToTest,numerTest(1),numerTest(2),mousetypeToTest) ./ ...
                 mag(:,:,datasetToTest,denomTest(1),denomTest(2),mousetypeToTest));
effFlag=repmat(sum(isfinite(magRatio),3),[1,1,numel(datasetToTest),1]);
magRatio(effFlag<effNum(mousetypeToTest))=nan;
phaseDiff=squeeze(phase(:,:,datasetToTest,numerTest(1),numerTest(2),mousetypeToTest) - ...
                  phase(:,:,datasetToTest,denomTest(1),denomTest(2),mousetypeToTest));
phaseDiff(effFlag<effNum(mousetypeToTest))=nan;
ST_phaseDiff=squeeze(phase(:,:,:,2,2,mousetypeToTest)-phase(:,:,:,3,2,mousetypeToTest));
ST_phaseDiff(effFlag<effNum(mousetypeToTest))=nan;
ST_phaseDiffAve=squeeze(nanmean(ST_phaseDiff,3));
ST_phaseDiffSE=squeeze(nanstd(ST_phaseDiff,[],3)) ...
    ./sqrt(sum(isfinite(ST_phaseDiff),3));

% take averages
if size(phaseDiff,3)>1
    magRatioAve=squeeze(nanmean(magRatio,3));
    magRatioSE=squeeze(nanstd(magRatio,[],3))./sqrt(sum(isfinite(magRatio),3)); 
    phaseDiffAve=squeeze(nanmean(phaseDiff,3))/2/pi;
    phaseDiffSE=squeeze(nanstd(phaseDiff,[],3))./sqrt(sum(isfinite(phaseDiff),3))/2/pi;
else
    magRatioAve=magRatio; 
    magRatioSE=zeros(size(magRatioAve));
    phaseDiffAve=phaseDiff/2/pi;
    phaseDiffSE=zeros(size(phaseDiffAve));
end
meanVal=nanmean(phaseDiffAve(:));

if numerTest(1)==3 && mousetypeToTest==1
    phaseDiffAve(phaseDiffAve>1.2)=phaseDiffAve(phaseDiffAve>1.2)-1;
elseif numerTest(1)==2 && mousetypeToTest==1
    phaseDiffAve(20:21,1:2)=nan;
    phaseDiffAve(22,3)=nan;
end

% magRatioAve(:,1:7)=nan;
figure(8); set(gcf,'Position', [50 100 350 250]); clf;
phasePlot_3(freq, ST_phaseDiffAve/2/pi, 0,...
    '','', '', [-1 1],ST_phaseDiffSE/2/pi); grid on;
figure(7); set(gcf,'Position', [450 100 350 250]); clf;
phasePlot_3(freq, phaseDiffAve, 0,'','','', ...
    [-1 1],phaseDiffSE); grid on;
figure(6); set(gcf,'Position', [450 400 350 250]); clf;
magPlot_3(freq, magRatioAve, 0,'','','', ...
    [0.1, 20],magRatioSE); grid on;

% print ratio difference between CF and RF in dead mouse
if mousetypeToTest==1
    RFidx=7; CFidx=19; % freq index for RF and CF
    magRatioTemp=squeeze(magRatio(:,8,:));
    magRatioRatio=20*log10(magRatioTemp(CFidx,:)./magRatioTemp(RFidx,:));
    fprintf('Ratio of at CF to BF = %0.1f +- %0.1f dB\n', ...
        nanmean(magRatioRatio),nanstd(magRatioRatio)/sqrt(sum(isfinite(magRatioRatio))));
elseif mousetypeToTest==2
    RFidx=7; CFidx=17; % freq index for RF and CF
    magRatioTemp=squeeze(nanmean(magRatio,2));
    magRatioRatio=20*log10(magRatioTemp(CFidx,:)./magRatioTemp(RFidx,:));
    fprintf('Ratio of at CF to BF = %0.1f +- %0.1f dB\n', ...
        nanmean(magRatioRatio),nanstd(magRatioRatio)/sqrt(sum(isfinite(magRatioRatio))));
elseif mousetypeToTest==5
    RFidx=6; CFidx=17; % freq index for RF and CF
    magRatioTemp=squeeze(nanmean(magRatio,2));
    magRatioRatio=20*log10(magRatioTemp(CFidx,:)./magRatioTemp(RFidx,:));
    fprintf('Ratio of at CF to BF = %0.1f +- %0.1f dB\n', ...
        nanmean(magRatioRatio),nanstd(magRatioRatio)/sqrt(sum(isfinite(magRatioRatio))));
end

%% ST bundle deflection and its ratio to other structure's motion
denom=[1,1]; % indices for [structure,direction] in the denominator
mousetypeToTest=1;
effNum=[4,3,3,3,4,4]; nPolMag=[4,3,5,5,6,6]; nPolPhase=[4,3,3,3,3,3];
useProcData=1; % set it to '1' if you want to use pre-processed data

ST_re=mag(:,:,:,2,2,mousetypeToTest).*cos(phase(:,:,:,2,2,mousetypeToTest)) - ...
    mag(:,:,:,3,2,mousetypeToTest).*cos(phase(:,:,:,3,2,mousetypeToTest));
ST_im=mag(:,:,:,2,2,mousetypeToTest).*sin(phase(:,:,:,2,2,mousetypeToTest)) - ...
    mag(:,:,:,3,2,mousetypeToTest).*sin(phase(:,:,:,3,2,mousetypeToTest));
effFlag=repmat(sum(isfinite(ST_re),3),[1,1,numData]);
ST_re(effFlag<effNum(mousetypeToTest))=nan;
ST_im(effFlag<effNum(mousetypeToTest))=nan;
ST_mag=abs(ST_re+1j*ST_im);
ST_phase=angle(ST_re+1j*ST_im);

ST_reAve=squeeze(nanmean(ST_re,3)); 
ST_imAve=squeeze(nanmean(ST_im,3));

ST_magAve=squeeze(nanmean(ST_mag,3));
ST_phaseRep=angle(ST_reAve+1j*ST_imAve); % representative ST phase value
ST_phase(ST_phase<repmat(ST_phaseRep,[1,1,numData])-pi) = ...
    ST_phase(ST_phase<repmat(ST_phaseRep,[1,1,numData])-pi) + 2*pi;
ST_phase(ST_phase>repmat(ST_phaseRep,[1,1,numData])+pi) = ...
    ST_phase(ST_phase>repmat(ST_phaseRep,[1,1,numData])+pi) - 2*pi;
ST_phaseAve=squeeze(nanmedian(ST_phase,3))+pi;
ST_phaseAve=unwrap(ST_phaseAve,1);

ST_magSE=squeeze(nanstd(ST_mag,[],3))./sqrt(sum(isfinite(ST_mag),3)); 
ST_phaseSE=squeeze(nanstd(ST_phase,[],3))./sqrt(sum(isfinite(ST_phase),3)); 

% convert displacement into angular deflection
STlen=1e3; % length of the ST
ST_angAve=atand(ST_magAve/STlen);
ST_angSE=atand(ST_magSE/STlen);
angRatioAve=squeeze(ST_angAve./squeeze(magAve(:,:,denom(1),denom(2),mousetypeToTest)));

if useProcData==1
    ST_phase_proc=load('stPhaseProc'); 
    ST_phase_proc=ST_phase_proc.ST_phase_proc;
    ST_phaseAve=squeeze(ST_phase_proc(:,:,mousetypeToTest));
end
magRatioAve=squeeze(ST_magAve./squeeze(magAve(:,:,denom(1),denom(2),mousetypeToTest)));
phaseDiffAve=squeeze(ST_phaseAve-squeeze(phaseAve(:,:,denom(1),denom(2),mousetypeToTest)));
phaseAdj=[0,0,0.2,0.3,0.5,0.8,1,1,3,2.5, ...
          2.8,3.0,2.9,2.5,1.7,1.4,1.1,0.7,0.5,0.4,0.3,0,0];
    
figure(12); set(gcf,'Position', [500 100 350 250]); clf;
phasePlot_3(freq, phaseDiffAve/2/pi, 0, ...
    '','', '', [-1.5 1.5],ST_phaseSE/2/pi); grid on;
figure(11); set(gcf,'Position', [500 400 350 250]); clf;
magPlot_3(freq, magRatioAve,0,'','', '', [0.02, 20], ...
    ST_magSE./squeeze(magAve(:,:,denom(1),denom(2),mousetypeToTest))); grid on;
% magPlot_3(freq, angRatioAve,0,'','', '', [0.002, 2], ...
%     ST_angSE./squeeze(magAve(:,:,denom(1),denom(2),mousetypeToTest))); grid on;
figure(10); set(gcf,'Position', [150 100 350 250]); clf;
phasePlot_3(freq, ST_phaseAve/2/pi, 0,...
    '','', '', [-5 1],ST_phaseSE/2/pi); grid on; set(gca,'Xtick',2:2:12,'Ytick',-10:1:2);
figure(9); set(gcf,'Position', [150 400 350 250]); clf;
magPlot_3(freq, ST_magAve, 0, ...
    '','', '', [],ST_magSE); grid on; grid minor; set(gca,'ytick',10.^(-1:2)); 
% magPlot_3(freq, ST_angAve, 0, ...
%     '','', '', [0.01 100],ST_angSE); grid on; grid minor; set(gca,'ytick',10.^(-1:2)); 

% print mean,std of gain between 10 and 80 db peaks in ST
if mousetypeToTest==1
    gain=squeeze(nanmax(ST_mag(:,1,:),[],1)*10^(7/2)./ ...
        nanmax(ST_mag(:,8,:),[],1)); 
    gain=20*log10(gain);
    fprintf('Gain: Mean = %0.1f dB, SE = %0.1f dB\n',nanmean(gain), ...
        nanstd(gain)/sqrt(sum(isfinite(gain))));
end
% do 2-way ANOVA for ST_phase


%% major axis
dispIdx=[3,2]; % indexes for the [structure, mousetype]
effNum=[3,2,2,2,3,2];
useProcData=0; % set it to '1' if you want to use pre-processed data

Nt=100; % number of angle segments to test
theta=linspace(0,pi,Nt+1); theta=theta(1:end-1);
magInst=nan(size(mag,1),size(mag,2),numel(theta));
phOffset=pi;
for i=1:numel(theta)
    magInstTemp = sqrt( magAve(:,:,dispIdx(1),1,dispIdx(2)).^2 .* ...
      ( sin( theta(i)+phaseAve(:,:,dispIdx(1),1,dispIdx(2)) ) ).^2  + ...
                        magAve(:,:,dispIdx(1),2,dispIdx(2)).^2 .* ...
      ( sin( theta(i)+phaseAve(:,:,dispIdx(1),2,dispIdx(2))+phOffset ) ).^2 );
    magInst(:,:,i) = squeeze(magInstTemp);
end

[maxMagAve, maxIdx]=max(magInst,[],3);
% 
% effFlag=repmat(sum(isfinite(maxMag),3),[1,1,numData]);
% maxMag(effFlag<effNum(dispIdx(2)))=nan; 
% maxMagAve=10.^(nanmean(log10(maxMag),3));
% maxMagSE=nanstd(maxMag,[],3)./sqrt(sum(isfinite(maxMag),3));

maxTheta=theta([maxIdx]);
maxTheta(isnan(maxMagAve))=nan;
% calculate the angle of the major axis of the motion
majAngleAve=atan2(    magAve(:,:,dispIdx(1),1,dispIdx(2)) .* ...
    sin( maxTheta + phaseAve(:,:,dispIdx(1),1,dispIdx(2)) ), ...
                      magAve(:,:,dispIdx(1),2,dispIdx(2)) .* ...
    sin( maxTheta + phaseAve(:,:,dispIdx(1),2,dispIdx(2))+phOffset ) );
majAngleAve(majAngleAve<0)=majAngleAve(majAngleAve<0)+pi;
thresMag=2;
majAngleAve(maxMagAve<thresMag)=nan;

% majAngleAve=zeros(size(majAngle,1),size(majAngle,2));
% majAngleSE=zeros(size(majAngle,1),size(majAngle,2));
% for i=1:numF
%     for j=1:numA
% %         [majAngleAve(i,j),magAngleSE(i,j)]= ...
% %             aveAngles(majAngle(i,j,:),effNum(dispIdx(2)));
%     end
% end
majAngleAve=unwrap(majAngleAve*2,1)/2;
magAngleSE=zeros(size(majAngleAve));

if useProcData==1
    majAngleAve=load('majAngleAveProc'); 
    ST_phase_proc=ST_phase_proc.ST_phase_proc;
    majAngleAve=squeeze(majAngleAveProc(:,:,dispIdx(1),dispIdx(2)));
end

figure(13); set(gcf,'Position', [300 100 350 250]); clf;
anglePlot_3(freq, majAngleAve/pi*180, 0,'','', '',[-30, 210],magAngleSE/pi*180); grid on;
figure(14); set(gcf,'Position', [300 400 350 250]); clf;
magPlot_3(freq, maxMagAve, 0,'','', '', [],[]); 
 grid on; grid minor; set(gca,'ytick',10.^(-1:2)); 





